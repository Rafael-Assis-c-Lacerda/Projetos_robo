const int DELAY = 2000;

//pinos sensores


const int PINO_SET = 3;

const int PINO_U0 = A0;
const int PINO_U1 = A1;
const int PINO_U2 = A2;
const int PINO_U3 = A3;
const int PINO_U4 = A4;
const int PINO_U5 = A5;
const int PINO_U6 = A6;
const int PINO_U7 = A7;
const int PINO_U8 = A8;


const int PINO_SDT = 2;


//pinos motor
const int IN1 = 8;
const int IN2 = 9;
const int ENA = 10;
const int IN3 = 12;
const int IN4 = 13;
const int ENB = 11;

//limiares

const int LIMIAR_U0 = 100;
const int LIMIAR_U1 = 100;
const int LIMIAR_U2 = 100;
const int LIMIAR_U3 = 100;
const int LIMIAR_U4 = 100;
const int LIMIAR_U5 = 100;
const int LIMIAR_U6 = 100;
const int LIMIAR_U7 = 100;
const int LIMIAR_U8 = 100;


int valor_U0;
int valor_U1;
int valor_U2;
int valor_U3;
int valor_U4;
int valor_U5;
int valor_U6;
int valor_U7;
int valor_U8;


bool U0;
bool U1;
bool U2;
bool U3;
bool U4;
bool U5;
bool U6;
bool U7;
bool U8;


