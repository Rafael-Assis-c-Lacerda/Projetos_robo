const int DELAY = 2000;




//pinos motor
const int IN1 = 9;
const int IN2 = 8;
const int ENA = 10;
const int IN3 = 7;
const int IN4 = 6;
const int ENB = 5;







